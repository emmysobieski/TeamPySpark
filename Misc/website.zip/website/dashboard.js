
  function pageLoad() {
    d3.json("formatted_dropdown_dashboard.json").then((data) => {
    d3.select(window).on("load", data.sample);
    //buildMetadata(0);
    //buildCharts("Afghanistan");
    buildCharts2(0);
  });
}

    // creating a bubble chart
    function buildCharts2(sample) {
        d3.json("formatted_dropdown_dashboard.json").then((data) => {
                console.log("hello");
    
            var total_loan_number = data.total_loans_per_country[sample];
            var time_to_fund = data.avg_funding_time[sample];

            console.log(total_loan_number);
            console.log(time_to_fund);     

            var trace1 = {
                x: [total_loan_number],
                y: [time_to_fund],
                text: ["Average Number of Days to Receive Funding:", [total_loan_number]],
                mode: "markers",
                    marker: {
                        color: 'time_to_fund',
                        size: 'total_loan_number',
                        colorScale: "Electric",
                        type: "heatmap"
                    }};

            var data2 = [trace1];
            
            var layout = {
                title: 'Kiva Loan Time vs. Number of Loans by Country',
                xaxis: {title: "Number of Loans Total for Country"},
                yaxis: {title: "Number of Days until Funding Success!"},
                //showlegend: true,
                //height: 600,
                //width: 600
            };

            Plotly.newPlot("bubble", data2, layout);
        });
    };


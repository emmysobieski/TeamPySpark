// API key
const API_KEY = "pk.eyJ1Ijoic2hlcmlwMjMiLCJhIjoiY2tiNnNvd3cwMDFyNDJ5bjB4eW16OXB0eSJ9.gsVhLOjyHvO1p2Qb6nXtfw"
